clear all

cd "DIRECTORY" // Replace with data directory here

use  "DATA_FILENAME.dta"  // CPS Extract from IPUMS

gen combined_race_ethnicity = .
replace combined_race_ethnicity = 1 if race == 651 & hispan == 0 // Asian alone, non-Hispanic
replace combined_race_ethnicity = 2 if race == 200 & hispan == 0 // Black alone, non-Hispanic
replace combined_race_ethnicity = 3 if race == 100 & hispan == 0 // White alone, non-Hispanic
replace combined_race_ethnicity = 4 if hispan == 0 & race != 100 & race != 200 & race != 651 // Non-Hispanic, some other race or multiracial
replace combined_race_ethnicity = 5 if hispan == 611 | hispan == 500 // Hispanic, Central American + Salvadorean
replace combined_race_ethnicity = 6 if hispan == 300 // Hispanic, Cuban
replace combined_race_ethnicity = 7 if hispan == 100 // Hispanic, Mexican
replace combined_race_ethnicity = 8 if hispan == 612 // Hispanic, South American 
replace combined_race_ethnicity = 9 if hispan == 600 | hispan == 200 | hispan == 400 // Hispanic, Other (incl PR and Dominican)
assert combined_race_ethnicity != .

* NOTE: native_born includes the following values of the 'nativity' variable:
* 'unknown'
* 'native-born: both parents native-born'
* 'native-born: father foreign, mother native'
* 'native-born: mother foreign, father native'
* 'native-born: both parents foreign'
assert nativity != .
gen native_born = 1 if nativity != 5 // 
replace native_born = 0 if nativity == 5 // nativity == 'foreign born'

* Merge in adjusted CPS weights
merge m:1 year age sex combined_race_ethnicity native_born using "data\Census_Through_2020_Plus_CBO_Projection_Wtfinl.dta"

gen adj_wtfinl = wtfinl * wtfinl_delta
