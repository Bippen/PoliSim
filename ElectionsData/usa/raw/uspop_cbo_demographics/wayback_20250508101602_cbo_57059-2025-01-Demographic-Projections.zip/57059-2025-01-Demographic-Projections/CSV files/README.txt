# Annual Projections of Demographic Variables

This data supplements CBO's January 2025 report The Demographic Outlook: 2025 to 2055.
https://www.cbo.gov/publication/60875

## Contents
-----------------------------------------------------------------------------------------------------
-- FILENAME --				        -- DESCRIPTION --
-----------------------------------------------------------------------------------------------------
README.txt					This file
blsThrough2024+CBOProjection_byYearAgeSex	Bureau of Labor Statistics Data Through 2024 Plus CBO’s Projections of the Civilian Noninstitutionalized Population, by Age and Sex
censusThrough2020+CBOProjection_byYearAgeSex	Census Data Through 2020 Plus CBO’s Projections of the Civilian Noninstitutionalized Population, by Age and Sex
fertilityRates_byYearAgePlace			Fertility Rates, by Age and Place of Birth
grossMigration_byYearAgeSexStatusFlow		Migration Flows, by Age, Sex, Immigration Status, and Flow Type
mortalityRates_byYearAgeSex			Mortality Rates, by Age and Sex
ssArea_pop_byYearAgeMaritalSex			Social Security Area Population, by Age, Marital Status, and Sex


To open the files without being restricted to read-only access, save the zipped archive to a 
local file directory and extract the files to a new directory.

## General Notes ##

All data files are in comma-separated values format.

Column headings are in row 1; data start in row 2.

Abbreviations used in these files:  
INA = Immigration and Nationality Act
LPR = lawful permanent resident
OFN = other foreign national

For more information about the immigration status categories that CBO used in its analysis 
(INA nonimmigrant, LPR+, and other foreign national), see Appendix C of the report. 

Corrections and Updates
On May 2, 2025, CBO reposted the zipped archive to correct values in the following CSV files:
 - blsThrough2024+CBOProjection_byYearAgeSex.csv
 - censusThrough2020+CBOProjection_byYearAgeSex.csv